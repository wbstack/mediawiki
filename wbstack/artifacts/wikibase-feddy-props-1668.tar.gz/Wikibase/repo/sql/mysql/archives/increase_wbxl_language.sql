ALTER TABLE /*_*/wbt_text_in_lang MODIFY wbxl_language VARBINARY(20) NOT NULL;
