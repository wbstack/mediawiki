-- Dropping wb_items_per_site.wb_ips_site_page. See T179793

DROP INDEX /*i*/wb_ips_site_page ON /*_*/wb_items_per_site;
