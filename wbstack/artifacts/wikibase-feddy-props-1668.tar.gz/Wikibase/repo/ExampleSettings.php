<?php

require __DIR__ . '/config/Wikibase.example.php';
